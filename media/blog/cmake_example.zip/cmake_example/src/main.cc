#include <iostream>
#include "geolib.h"

using namespace std;

struct point {
	double latitude;
	double longitude;
};

int main() {
	// Berlin: 52.614723,13.373108
	// Munich: 48.189895,11.560364
	struct point p1 = {52.62, 13.37};
	struct point p2 = {48.19, 11.56};

	double d = geolib::great_circle_distance(p1.latitude, p1.longitude, p2.latitude, p2.longitude);

	cout << "Distance is " << d << "." << endl;

	return 0;
}
