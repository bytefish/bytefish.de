#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE "GeoLib Tests"
#include <boost/test/unit_test.hpp>
#include "geolib.h"

BOOST_AUTO_TEST_CASE(gcircle_test) {

	double expected = 2886.448973436;

	double bna_lat = 36.12;
	double bna_long = -86.67;
	double lax_lat = 33.94;
	double lax_long = -118.40;

	double actual = geolib::great_circle_distance(bna_lat, bna_long, lax_lat, lax_long);
	BOOST_CHECK_CLOSE(actual, expected, 1e-5);

}
