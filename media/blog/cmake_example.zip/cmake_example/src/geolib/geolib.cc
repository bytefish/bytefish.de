#include "geolib.h"

namespace geolib {
	
	double great_circle_distance(double lat1, double long1, double lat2, double long2) {
		
		lat1 *= DEG2RAD;
		long1 *= DEG2RAD;
		lat2 *= DEG2RAD;
		long2 *= DEG2RAD;

		double deltaLat = lat1-lat2;
		double deltaLong = long1-long2;
		double a = pow(sin(deltaLat/2.0),2.0) + cos(lat1) * cos(lat2) * pow(sin(deltaLong/2.0),2.0);
		double c = 2 * asin(sqrt(a));

		return EARTH_RADIUS * c;
	}


}

