#ifndef _geolib_h
#define _geolib_h
#include <math.h>

/**
* @author philipp
* @date 2010
*/
namespace geolib {
	
	const double DEG2RAD = M_PI / 180.0;
	const double RAD2DEG = 180.0 / M_PI;
	const double EARTH_RADIUS = 6371.01;
	
	/**
	 * @brief great-circle distance (shortest distance between two points on earth)
	 * @param[in] latitude point 1
	 * @param[in] longitude point 1
	 * @param[in] latitude point 2
	 * @param[in] longitude point 2
	 * @return great-circle distance
	 */
	double great_circle_distance(double lat1, double long1, double lat2, double long2);

}

#endif
